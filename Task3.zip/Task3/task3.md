1. Why are we using clamp() instead of media queries?
We use clamp() because it enables fluid typography that scales smoothly between a minimum and maximum size. Unlike media queries, which create abrupt jumps at breakpoints, clamp() provides continuous resizing based on the screen width, resulting in a better user experience with less code.

2. Why did we use minmax() instead of fixed columns?
minmax() allows flexible layouts where elements can grow and shrink depending on available space. Instead of fixed column sizes that may overflow or leave empty space, minmax(250px, 1fr) ensures elements stay readable while automatically adapting to different screen sizes.

3. Why is it important to implement a mobile-first website?
A mobile-first approach ensures better performance and simpler design by starting with the smallest screens and progressively enhancing for larger devices. It reduces unnecessary CSS overrides and improves usability on mobile devices, which are often more limited.

4. What happens if we remove the variables defined at the beginning?
If the variables are removed, styles using var() will break or fall back to default values, causing inconsistent design. It also makes maintenance harder, since changes like colors or spacing would need to be updated manually in multiple places instead of one central location.